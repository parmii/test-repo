package com.solactive.ticksexportservice.controller;

import com.solactive.ticksexportservice.model.TicksData;
import com.solactive.ticksexportservice.util.JWTUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class TicksExportControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private RestTemplate restTemplate;
    @MockBean
    private JWTUtil jwtUtil;

    @Test
    public void testExportTicksByRIC() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + jwtUtil.generateToken());
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<String> request = new HttpEntity<>(headers);

        when(jwtUtil.generateToken()).thenReturn("jwt");
        TicksData ticksData = new TicksData();
        ticksData.setClosedPriceAvailable(true);
        when(restTemplate.exchange(eq("http://localhost:8080/ticks/ABC"), any(), any(), eq(TicksData.class))).thenReturn(new ResponseEntity(ticksData, HttpStatus.OK));
        this.mockMvc.perform(
                        get("/export/ABC").contentType(MediaType.APPLICATION_JSON))
                .andDo(print()).andExpect(status().isOk());
    }
}
