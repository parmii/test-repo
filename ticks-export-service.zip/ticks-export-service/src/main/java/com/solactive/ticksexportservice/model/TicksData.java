package com.solactive.ticksexportservice.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
public class TicksData {
    private boolean isClosedPriceAvailable;
    private List<Tick> ticks = new ArrayList<>();
}
