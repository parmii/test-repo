package com.solactive.ticksexportservice.util;

import com.solactive.ticksexportservice.model.User;
import com.solactive.ticksexportservice.model.UserCredentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class JWTUtil {

    private final RestTemplate restTemplate;
    private final UserCredentials userCredentials;

    @Value("${consumer.service.uri}")
    private String consumerServiceURI;

    public JWTUtil(RestTemplate restTemplate, UserCredentials userCredentials) {
        this.restTemplate = restTemplate;
        this.userCredentials = userCredentials;
    }

    /**
     * This method will call the consumer service and fetch the token
     *
     * @return JWT token received from consumer service
     */
    public String generateToken() {
        String uri = consumerServiceURI + "/generateToken";
        User user = new User(userCredentials.getUsername(), userCredentials.getPassword());
        Map<String, String> jwtMap = restTemplate.postForObject(uri, user, Map.class);
        return jwtMap.get("jwt");
    }
}
