package com.solactive.ticksexportservice.constants;

public class Constants {
    public static final String CSV_COLUMNS = "TIMESTAMP,PRICE,CLOSE_PRICE,CURRENCY,RIC";
    public static final String MEDIA_TYPE_TEXT_CSV = "text/csv";
}
