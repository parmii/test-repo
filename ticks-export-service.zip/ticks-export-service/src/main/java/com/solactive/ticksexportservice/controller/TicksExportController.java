package com.solactive.ticksexportservice.controller;


import com.solactive.ticksexportservice.exception.ClosedPriceNotFoundException;
import com.solactive.ticksexportservice.model.Tick;
import com.solactive.ticksexportservice.model.TicksData;
import com.solactive.ticksexportservice.util.TicksDataUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.Date;
import java.util.Objects;

import static com.solactive.ticksexportservice.constants.Constants.CSV_COLUMNS;
import static com.solactive.ticksexportservice.constants.Constants.MEDIA_TYPE_TEXT_CSV;
import static com.solactive.ticksexportservice.constants.ErrorConstants.CLOSE_PRICE_NOT_FOUND_MESSAGE;
import static com.solactive.ticksexportservice.constants.ErrorConstants.EXPORT_TO_CSV_FAILED;

@Slf4j
@RestController
public class TicksExportController {

    private final TicksDataUtil ticksDataUtil;


    public TicksExportController(TicksDataUtil ticksDataUtil) {
        this.ticksDataUtil = ticksDataUtil;
    }

    /**
     * This method will export the CSV based on the RIC, If closed price for the given RIC is available
     *
     * @param ric      String RIC value should be provided
     * @param response CSV file will be generated as a response
     */
    @Operation(summary = "Export Ticks CSV by RIC if Closed price is available")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "CSV Generated Successfully")})
    @GetMapping(value = "/export/{ric}", produces = MEDIA_TYPE_TEXT_CSV)
    public void exportTicksByRIC(@PathVariable String ric, HttpServletResponse response) {
        TicksData ticksData = ticksDataUtil.fetchTicksByRIC(ric).get();
        if (!Objects.requireNonNull(ticksData).isClosedPriceAvailable())
            throw new ClosedPriceNotFoundException(CLOSE_PRICE_NOT_FOUND_MESSAGE);
        generateCSV(response, ticksData, ric);
    }

    /**
     * This is a private method which is responsible for generating the csv file
     *
     * @param response  CSV file
     * @param ticksData Data received from consumer service
     * @param ric       RIC received from the API URL
     */
    private void generateCSV(HttpServletResponse response, TicksData ticksData, String ric) {
        response.setContentType(MEDIA_TYPE_TEXT_CSV);
        String fileName = "tick-" + ric + "-" + new Date().getTime() + ".csv ";
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
        try (OutputStream outputStream = response.getOutputStream()) {
            StringBuilder sb = new StringBuilder();
            sb.append(CSV_COLUMNS).append("\n");
            for (Tick tick : Objects.requireNonNull(ticksData).getTicks()) {
                Date date = new Date(tick.getTimestamp() * 1000);
                sb.append(date).append(",").append(tick.getPrice()).append(",").append(tick.getClosePrice()).append(",").append(tick.getCurrency()).append(",").append(tick.getRic()).append("\n");
            }
            outputStream.write(sb.toString().getBytes());
            outputStream.flush();
        } catch (Exception e) {
            log.error(EXPORT_TO_CSV_FAILED, e);
        }
    }
}