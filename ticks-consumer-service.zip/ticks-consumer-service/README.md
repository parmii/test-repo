# Ticks Consumer Service

## Reference Documentation

For building and running the application you need:

- [JDK 11](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html)
- [Maven 3](https://maven.apache.org)

## Running the application locally

There are several ways to run a Spring Boot application on your local machine. One way is to execute the `main` method
in the `com.solactive.ticksconsumerservice.TicksConsumerServiceApplication` class from your IDE.

Alternatively you can use
the [Spring Boot Maven plugin](https://docs.spring.io/spring-boot/docs/current/reference/html/build-tool-plugins-maven-plugin.html)
like so:

```shell
mvn spring-boot:run
```

## Access application

Application be accessed using url http://localhost:8080/

## API Documentation

Detailed API Documentation available on http://localhost:8080/api-docs.html

### Available APIs

The REST APIs to the tick consumer service are described below.

###Add new ticks`

`POST /ticks`
curl --location --request POST 'http://localhost:8080/ticks' \ --header 'Content-Type: application/json' \ --data-raw '{"TIMESTAMP":"{TIMESTAMP}","PRICE":"{PRICE}","CURRENCY":"{CURRENCY}","RIC" : "{RIC}"}'

###Fetch all ticks for a given RIC if user has ADMIN role

`GET /ticks/{ric}`
curl --location --request GET 'http://localhost:8080/ticks/ABC' \--header 'Content-Type: application/json' \--header 'Authorization: Bearer {token}'