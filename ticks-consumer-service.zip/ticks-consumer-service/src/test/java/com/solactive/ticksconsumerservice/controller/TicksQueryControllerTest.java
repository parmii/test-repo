package com.solactive.ticksconsumerservice.controller;

import com.solactive.ticksconsumerservice.dto.TicksDataDto;
import com.solactive.ticksconsumerservice.service.TicksQueryService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class TicksQueryControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TicksQueryService ticksQueryService;

    @Test
    @WithMockUser(username = "admin", authorities = {"ADMIN"})
    public void testTicksDataFetch() throws Exception {
        when(ticksQueryService.fetchTicksDataByRIC(anyString())).thenReturn(new TicksDataDto());
        this.mockMvc.perform(
                        get("/ticks/ABC").contentType(MediaType.APPLICATION_JSON))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(content().string(containsString("ticks")));
    }
}
