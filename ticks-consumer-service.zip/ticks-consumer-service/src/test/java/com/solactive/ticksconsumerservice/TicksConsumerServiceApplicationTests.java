package com.solactive.ticksconsumerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicksConsumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
