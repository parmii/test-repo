package com.solactive.ticksconsumerservice.util;

import com.solactive.ticksconsumerservice.model.Tick;
import com.solactive.ticksconsumerservice.model.TicksData;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class TicksDataUtil {

    private static final Map<String, TicksData> ricToTickMap = new HashMap<>();

    public void save(Tick tick) {
        List<Tick> ticks = new ArrayList<>();
        ticks.add(tick);
        if (ricToTickMap.containsKey(tick.getRic())) {
            ticks.addAll(ricToTickMap.get(tick.getRic()).getTicks());
        }
        TicksData ticksData = TicksData.builder()
                .ticks(ticks)
                .isClosedPriceAvailable(tick.getClosePrice() != null)
                .build();
        ricToTickMap.put(tick.getRic(), ticksData);
    }

    public Optional<TicksData> fetchTicksByRIC(String ric) {
        return Optional.ofNullable(ricToTickMap.get(ric));
    }

}
