package com.solactive.ticksconsumerservice.service;

import com.solactive.ticksconsumerservice.model.Tick;
import com.solactive.ticksconsumerservice.util.TicksDataUtil;
import org.springframework.stereotype.Service;

@Service
public class TicksCommandServiceImpl implements TicksCommandService {

    private final TicksDataUtil ticksDataUtil;

    public TicksCommandServiceImpl(TicksDataUtil ticksDataUtil) {
        this.ticksDataUtil = ticksDataUtil;
    }

    @Override
    public void save(Tick tick) {
        ticksDataUtil.save(tick);
    }
}
