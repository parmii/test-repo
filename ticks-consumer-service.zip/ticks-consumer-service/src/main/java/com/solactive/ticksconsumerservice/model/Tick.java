package com.solactive.ticksconsumerservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Tick {

    @NotBlank(message = "Timestamp cannot be null")
    @JsonProperty("TIMESTAMP")
    private Long timestamp;

    @NotBlank(message = "Please provide tick price")
    @JsonProperty("PRICE")
    private Double price;

    @JsonProperty("CLOSE_PRICE")
    private Double closePrice;

    @NotBlank(message = "Please provide tick currency")
    @JsonProperty("CURRENCY")
    private String currency;

    @NotBlank(message = "Please provide tick RIC")
    @JsonProperty("RIC")
    private String ric;
}
