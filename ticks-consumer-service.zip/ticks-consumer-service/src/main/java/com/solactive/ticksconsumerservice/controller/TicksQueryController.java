package com.solactive.ticksconsumerservice.controller;

import com.solactive.ticksconsumerservice.dto.TickDataDto;
import com.solactive.ticksconsumerservice.dto.TicksDataDto;
import com.solactive.ticksconsumerservice.service.TicksQueryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TicksQueryController {
    private final TicksQueryService ticksQueryService;

    public TicksQueryController(TicksQueryService ticksQueryService) {
        this.ticksQueryService = ticksQueryService;
    }

    /**
     * @param ric
     * @return
     */
    @Operation(summary = "Lookup all tick values for a particular RIC")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Tick Fetched Successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = TickDataDto.class))}),
            @ApiResponse(responseCode = "403", description = "Access Denied")})
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping(value = "/ticks/{ric}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public TicksDataDto fetchTicksDataByRIC(@PathVariable String ric) {
        return ticksQueryService.fetchTicksDataByRIC(ric);
    }
}